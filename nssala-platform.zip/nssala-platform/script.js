// Language translations
const translations = {
    en: {
        greeting: "Hello! I'm your AI tutor.",
        askQuestion: "Ask me anything about",
        subjects: {
            physics: "Physics",
            chemistry: "Chemistry",
            biology: "Biology"
        }
    },
    ig: {
        greeting: "Ndewo! Abụ m onye nkuzi AI gị.",
        askQuestion: "Jụọ m ihe ọ bụla gbasara",
        subjects: {
            physics: "Physics",
            chemistry: "Chemistry", 
            biology: "Biology"
        }
    },
    ha: {
        greeting: "Sannu! Ni ne malamin AI naku.",
        askQuestion: "Tambaye ni komai game da",
        subjects: {
            physics: "Physics",
            chemistry: "Chemistry",
            biology: "Biology"
        }
    },
    yo: {
        greeting: "Pẹlẹ o! Emi ni olukọ AI rẹ.",
        askQuestion: "Beere lọwọ mi nipa",
        subjects: {
            physics: "Physics",
            chemistry: "Chemistry",
            biology: "Biology"
        }
    },
    ur: {
        greeting: "Migwo! Ame re AI teacher re.",
        askQuestion: "Bru me question for",
        subjects: {
            physics: "Physics",
            chemistry: "Chemistry",
            biology: "Biology"
        }
    }
};

// Current state
let currentLanguage = 'en';
let currentSubject = 'physics';
let quizData = null;
let currentQuizQuestion = 0;
let quizAnswers = [];
let quizStartTime = null;

// Topics database
const topics = {
    physics: [
        { title: "Newton's Laws of Motion", description: "Learn about force, mass, and acceleration" },
        { title: "Energy and Work", description: "Understanding kinetic and potential energy" },
        { title: "Electricity and Magnetism", description: "Circuits, current, and magnetic fields" },
        { title: "Waves and Sound", description: "Properties of waves and sound phenomena" },
        { title: "Light and Optics", description: "Reflection, refraction, and lenses" }
    ],
    chemistry: [
        { title: "Atomic Structure", description: "Protons, neutrons, and electrons" },
        { title: "Chemical Bonding", description: "Ionic and covalent bonds" },
        { title: "Acids and Bases", description: "pH scale and neutralization" },
        { title: "Organic Chemistry", description: "Hydrocarbons and functional groups" },
        { title: "Chemical Reactions", description: "Types of reactions and balancing equations" }
    ],
    biology: [
        { title: "Cell Biology", description: "Structure and function of cells" },
        { title: "Genetics", description: "DNA, genes, and inheritance" },
        { title: "Human Body Systems", description: "Circulatory, respiratory, digestive systems" },
        { title: "Evolution", description: "Natural selection and adaptation" },
        { title: "Ecology", description: "Ecosystems and environmental interactions" }
    ]
};

// English topics content
const englishTopics = {
    concord: {
        title: "Law of Concord (Subject-Verb Agreement)",
        content: `
            <h3>What is Concord?</h3>
            <p>Concord, also known as subject-verb agreement, means that the subject and verb in a sentence must agree in number (singular or plural).</p>
            
            <h4>Rules of Concord:</h4>
            <ul>
                <li><strong>Rule 1:</strong> Singular subjects take singular verbs
                    <br><em>Example: The student writes well.</em></li>
                <li><strong>Rule 2:</strong> Plural subjects take plural verbs
                    <br><em>Example: The students write well.</em></li>
                <li><strong>Rule 3:</strong> Collective nouns usually take singular verbs
                    <br><em>Example: The team is playing well.</em></li>
                <li><strong>Rule 4:</strong> 'Either...or' and 'Neither...nor' - verb agrees with nearest subject
                    <br><em>Example: Neither the teacher nor the students are here.</em></li>
                <li><strong>Rule 5:</strong> Words like 'everyone', 'someone', 'nobody' take singular verbs
                    <br><em>Example: Everyone is welcome.</em></li>
            </ul>
        `,
        practice: [
            {
                question: "The group of students ____ studying hard.",
                options: ["is", "are", "were", "be"],
                correct: 0
            },
            {
                question: "Either John or his friends ____ coming to the party.",
                options: ["is", "are", "was", "been"],
                correct: 1
            }
        ]
    },
    tenses: {
        title: "Tenses",
        content: `
            <h3>Understanding Tenses</h3>
            <p>Tenses show the time of an action or state of being.</p>
            
            <h4>Types of Tenses:</h4>
            <ul>
                <li><strong>Present Tense:</strong> Actions happening now
                    <br><em>Simple: I write. Continuous: I am writing. Perfect: I have written.</em></li>
                <li><strong>Past Tense:</strong> Actions that happened before
                    <br><em>Simple: I wrote. Continuous: I was writing. Perfect: I had written.</em></li>
                <li><strong>Future Tense:</strong> Actions that will happen
                    <br><em>Simple: I will write. Continuous: I will be writing. Perfect: I will have written.</em></li>
            </ul>
        `,
        practice: [
            {
                question: "She ____ to school every day.",
                options: ["go", "goes", "going", "gone"],
                correct: 1
            },
            {
                question: "They ____ football when it started raining.",
                options: ["play", "plays", "were playing", "will play"],
                correct: 2
            }
        ]
    },
    speech: {
        title: "Parts of Speech",
        content: `
            <h3>The Eight Parts of Speech</h3>
            <ul>
                <li><strong>Noun:</strong> Names of people, places, things (boy, Lagos, book)</li>
                <li><strong>Pronoun:</strong> Replaces nouns (he, she, it, they)</li>
                <li><strong>Verb:</strong> Action or state of being (run, is, have)</li>
                <li><strong>Adjective:</strong> Describes nouns (beautiful, tall, red)</li>
                <li><strong>Adverb:</strong> Describes verbs, adjectives (quickly, very, well)</li>
                <li><strong>Preposition:</strong> Shows relationship (in, on, at, under)</li>
                <li><strong>Conjunction:</strong> Connects words/phrases (and, but, or)</li>
                <li><strong>Interjection:</strong> Expresses emotion (wow!, oh!, ouch!)</li>
            </ul>
        `,
        practice: [
            {
                question: "In 'The quick brown fox jumps', what part of speech is 'quick'?",
                options: ["Noun", "Adjective", "Verb", "Adverb"],
                correct: 1
            }
        ]
    },
    punctuation: {
        title: "Punctuation Marks",
        content: `
            <h3>Important Punctuation Marks</h3>
            <ul>
                <li><strong>Period (.):</strong> Ends a statement</li>
                <li><strong>Comma (,):</strong> Separates items or clauses</li>
                <li><strong>Question Mark (?):</strong> Ends a question</li>
                <li><strong>Exclamation Mark (!):</strong> Shows strong emotion</li>
                <li><strong>Apostrophe ('):</strong> Shows possession or contraction</li>
                <li><strong>Quotation Marks (""):</strong> Encloses direct speech</li>
                <li><strong>Colon (:):</strong> Introduces a list or explanation</li>
                <li><strong>Semicolon (;):</strong> Connects related clauses</li>
            </ul>
        `,
        practice: [
            {
                question: "Which punctuation is correct? 'Its a beautiful day' or 'It's a beautiful day'",
                options: ["Its", "It's", "Its'", "It is"],
                correct: 1
            }
        ]
    },
    composition: {
        title: "Essay Writing",
        content: `
            <h3>How to Write a Good Essay</h3>
            <h4>Essay Structure:</h4>
            <ul>
                <li><strong>Introduction:</strong> Introduce the topic and thesis statement</li>
                <li><strong>Body Paragraphs:</strong> Develop your arguments with evidence</li>
                <li><strong>Conclusion:</strong> Summarize and restate your thesis</li>
            </ul>
            <h4>Types of Essays:</h4>
            <ul>
                <li>Narrative Essay - Tells a story</li>
                <li>Descriptive Essay - Describes a person, place, or thing</li>
                <li>Argumentative Essay - Presents an argument</li>
                <li>Expository Essay - Explains or informs</li>
            </ul>
        `,
        practice: [
            {
                question: "Which part of an essay introduces the main idea?",
                options: ["Body", "Conclusion", "Introduction", "Summary"],
                correct: 2
            }
        ]
    },
    comprehension: {
        title: "Reading Comprehension",
        content: `
            <h3>Strategies for Better Comprehension</h3>
            <ul>
                <li><strong>Preview:</strong> Look at headings and structure before reading</li>
                <li><strong>Read Actively:</strong> Underline key points and take notes</li>
                <li><strong>Question:</strong> Ask yourself questions about the text</li>
                <li><strong>Summarize:</strong> Retell the main ideas in your own words</li>
                <li><strong>Visualize:</strong> Create mental images of what you read</li>
            </ul>
        `,
        practice: [
            {
                question: "What does 'preview' mean in reading comprehension?",
                options: [
                    "Reading very slowly",
                    "Looking at the structure before reading",
                    "Memorizing everything",
                    "Skipping difficult parts"
                ],
                correct: 1
            }
        ]
    }
};

// Quiz questions database
const quizQuestions = {
    physics: [
        {
            question: "What is Newton's First Law of Motion?",
            options: [
                "Force equals mass times acceleration",
                "An object at rest stays at rest unless acted upon by force",
                "For every action, there's an equal and opposite reaction",
                "Energy cannot be created or destroyed"
            ],
            correct: 1
        },
        {
            question: "What is the SI unit of force?",
            options: ["Joule", "Newton", "Watt", "Pascal"],
            correct: 1
        },
        {
            question: "Which type of energy does a moving car possess?",
            options: ["Potential Energy", "Kinetic Energy", "Chemical Energy", "Nuclear Energy"],
            correct: 1
        },
        {
            question: "What happens to the resistance in a circuit when more bulbs are added in series?",
            options: ["Decreases", "Stays the same", "Increases", "Becomes zero"],
            correct: 2
        },
        {
            question: "The speed of light in vacuum is approximately:",
            options: ["3 × 10⁸ m/s", "3 × 10⁶ m/s", "3 × 10⁴ m/s", "3 × 10² m/s"],
            correct: 0
        },
        {
            question: "What is the formula for calculating work done?",
            options: ["W = F × d", "W = m × a", "W = P × V", "W = m × v"],
            correct: 0
        },
        {
            question: "Which of these is a vector quantity?",
            options: ["Speed", "Mass", "Velocity", "Temperature"],
            correct: 2
        },
        {
            question: "The bending of light as it passes from one medium to another is called:",
            options: ["Reflection", "Diffraction", "Refraction", "Dispersion"],
            correct: 2
        },
        {
            question: "What is the acceleration due to gravity on Earth?",
            options: ["9.8 m/s²", "10 m/s²", "8.9 m/s²", "11 m/s²"],
            correct: 0
        },
        {
            question: "In which direction does heat flow?",
            options: [
                "From cold to hot",
                "From hot to cold",
                "In all directions equally",
                "It doesn't flow"
            ],
            correct: 1
        }
    ],
    chemistry: [
        {
            question: "What is the chemical symbol for Gold?",
            options: ["Go", "Gd", "Au", "Ag"],
            correct: 2
        },
        {
            question: "How many elements are in the periodic table?",
            options: ["92", "108", "118", "126"],
            correct: 2
        },
        {
            question: "What is the pH of pure water?",
            options: ["6", "7", "8", "9"],
            correct: 1
        },
        {
            question: "Which gas is most abundant in Earth's atmosphere?",
            options: ["Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"],
            correct: 2
        },
        {
            question: "What type of bond is formed when electrons are shared?",
            options: ["Ionic bond", "Covalent bond", "Metallic bond", "Hydrogen bond"],
            correct: 1
        },
        {
            question: "The chemical formula for water is:",
            options: ["H₂O", "HO₂", "H₂O₂", "HO"],
            correct: 0
        },
        {
            question: "Which of these is an acid?",
            options: ["NaOH", "KOH", "HCl", "NH₃"],
            correct: 2
        },
        {
            question: "What is the atomic number of Carbon?",
            options: ["4", "6", "8", "12"],
            correct: 1
        },
        {
            question: "Which process converts liquid to gas?",
            options: ["Condensation", "Evaporation", "Sublimation", "Deposition"],
            correct: 1
        },
        {
            question: "What is the simplest hydrocarbon?",
            options: ["Ethane", "Propane", "Methane", "Butane"],
            correct: 2
        }
    ],
    biology: [
        {
            question: "What is the powerhouse of the cell?",
            options: ["Nucleus", "Mitochondria", "Ribosome", "Chloroplast"],
            correct: 1
        },
        {
            question: "Which blood type is known as the universal donor?",
            options: ["A", "B", "AB", "O"],
            correct: 3
        },
        {
            question: "What is the process by which plants make food?",
            options: ["Respiration", "Photosynthesis", "Digestion", "Fermentation"],
            correct: 1
        },
        {
            question: "How many chromosomes do humans have?",
            options: ["23", "46", "48", "52"],
            correct: 1
        },
        {
            question: "Which organ pumps blood throughout the body?",
            options: ["Liver", "Kidney", "Heart", "Lungs"],
            correct: 2
        },
        {
            question: "DNA stands for:",
            options: [
                "Deoxyribonucleic Acid",
                "Dinitrogen Acid",
                "Dynamic Nuclear Acid",
                "Double Nitrogen Acid"
            ],
            correct: 0
        },
        {
            question: "What is the largest organ in the human body?",
            options: ["Heart", "Liver", "Brain", "Skin"],
            correct: 3
        },
        {
            question: "Which vitamin is produced when skin is exposed to sunlight?",
            options: ["Vitamin A", "Vitamin C", "Vitamin D", "Vitamin E"],
            correct: 2
        },
        {
            question: "What type of blood vessel carries blood away from the heart?",
            options: ["Vein", "Artery", "Capillary", "Venule"],
            correct: 1
        },
        {
            question: "What is the basic unit of life?",
            options: ["Atom", "Molecule", "Cell", "Organ"],
            correct: 2
        }
    ],
    mathematics: [
        {
            question: "What is 15% of 200?",
            options: ["20", "25", "30", "35"],
            correct: 2
        },
        {
            question: "Solve: 2x + 5 = 15. What is x?",
            options: ["5", "10", "7.5", "20"],
            correct: 0
        },
        {
            question: "What is the value of π (pi) approximately?",
            options: ["3.14", "2.71", "1.41", "4.00"],
            correct: 0
        },
        {
            question: "What is the sum of angles in a triangle?",
            options: ["90°", "180°", "270°", "360°"],
            correct: 1
        },
        {
            question: "What is 7²?",
            options: ["14", "21", "49", "56"],
            correct: 2
        },
        {
            question: "Which of these is a prime number?",
            options: ["15", "21", "23", "27"],
            correct: 2
        },
        {
            question: "What is the area of a rectangle with length 5m and width 3m?",
            options: ["8 m²", "15 m²", "10 m²", "18 m²"],
            correct: 1
        },
        {
            question: "Simplify: 3x + 2x",
            options: ["5x", "6x", "5x²", "3x²"],
            correct: 0
        },
        {
            question: "What is the square root of 64?",
            options: ["6", "7", "8", "9"],
            correct: 2
        },
        {
            question: "Convert 0.75 to a fraction:",
            options: ["1/2", "3/4", "2/3", "4/5"],
            correct: 1
        }
    ],
    english: [
        {
            question: "Choose the correct verb: 'The team ____ playing well.'",
            options: ["is", "are", "were", "been"],
            correct: 0
        },
        {
            question: "Which is the correct plural of 'child'?",
            options: ["childs", "childes", "children", "childrens"],
            correct: 2
        },
        {
            question: "Identify the noun: 'She quickly ran to the store.'",
            options: ["She", "quickly", "ran", "store"],
            correct: 3
        },
        {
            question: "Which sentence is correct?",
            options: [
                "He don't like it",
                "He doesn't like it",
                "He doesn't likes it",
                "He don't likes it"
            ],
            correct: 1
        },
        {
            question: "What is the past tense of 'run'?",
            options: ["runed", "ran", "runned", "running"],
            correct: 1
        },
        {
            question: "Which is a conjunction?",
            options: ["quickly", "and", "beautiful", "under"],
            correct: 1
        },
        {
            question: "Choose the correct: 'Between you and ____'",
            options: ["I", "me", "myself", "mine"],
            correct: 1
        },
        {
            question: "Which punctuation ends a question?",
            options: [".", "!", "?", ","],
            correct: 2
        },
        {
            question: "What type of word is 'beautiful'?",
            options: ["Noun", "Verb", "Adjective", "Adverb"],
            correct: 2
        },
        {
            question: "Which is correct: 'Their' or 'There' in 'Put it over ____'",
            options: ["their", "there", "they're", "thier"],
            correct: 1
        }
    ]
};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeLanguageSelector();
    initializeAITutor();
    initializeEnglishSection();
    loadTopics(currentSubject);
});

// Navigation
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            const target = this.getAttribute('href');
            scrollToSection(target.substring(1));
        });
    });
}

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
    }
}

// Language selector
function initializeLanguageSelector() {
    const languageSelect = document.getElementById('languageSelect');
    languageSelect.addEventListener('change', function() {
        currentLanguage = this.value;
        updateLanguage();
    });
}

function updateLanguage() {
    const trans = translations[currentLanguage];
    // Update AI tutor greeting if exists
    const firstMessage = document.querySelector('.bot-message .message-content p');
    if (firstMessage) {
        firstMessage.innerHTML = `${trans.greeting} ${trans.askQuestion} <span id="currentSubject">${trans.subjects[currentSubject]}</span>!`;
    }
}

// AI Tutor
function initializeAITutor() {
    const subjectTabs = document.querySelectorAll('.subject-tab');
    subjectTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            subjectTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            currentSubject = this.dataset.subject;
            loadTopics(currentSubject);
            updateLanguage();
        });
    });

    // Enter key support
    const tutorInput = document.getElementById('tutorInput');
    if (tutorInput) {
        tutorInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendTutorMessage();
            }
        });
    }
}

function loadTopics(subject) {
    const topicsGrid = document.getElementById('topicsGrid');
    if (!topicsGrid) return;
    
    topicsGrid.innerHTML = '';
    topics[subject].forEach(topic => {
        const topicBtn = document.createElement('button');
        topicBtn.className = 'topic-btn';
        topicBtn.innerHTML = `<strong>${topic.title}</strong><br><small>${topic.description}</small>`;
        topicBtn.onclick = () => askAboutTopic(topic.title);
        topicsGrid.appendChild(topicBtn);
    });
}

function askAboutTopic(topicTitle) {
    const input = document.getElementById('tutorInput');
    input.value = `Explain ${topicTitle}`;
    sendTutorMessage();
}

function sendTutorMessage() {
    const input = document.getElementById('tutorInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addMessage(message, 'user');
    
    // Simulate AI response
    setTimeout(() => {
        const response = generateAIResponse(message);
        addMessage(response, 'bot');
    }, 1000);
    
    input.value = '';
}

function addMessage(text, type) {
    const chatMessages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}-message`;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = type === 'bot' ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    content.innerHTML = `<p>${text}</p>`;
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    chatMessages.appendChild(messageDiv);
    
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function generateAIResponse(question) {
    const trans = translations[currentLanguage];
    const lowerQuestion = question.toLowerCase();
    
    // Simple keyword-based responses
    if (lowerQuestion.includes('newton') || lowerQuestion.includes('motion')) {
        return getTranslatedResponse(
            "Newton's First Law states that an object at rest stays at rest and an object in motion stays in motion unless acted upon by an external force. This is also known as the law of inertia.",
            currentLanguage
        );
    } else if (lowerQuestion.includes('energy')) {
        return getTranslatedResponse(
            "Energy is the ability to do work. There are different forms: kinetic energy (energy of motion), potential energy (stored energy), thermal energy (heat), and more. Energy cannot be created or destroyed, only transformed from one form to another.",
            currentLanguage
        );
    } else if (lowerQuestion.includes('atom') || lowerQuestion.includes('atomic')) {
        return getTranslatedResponse(
            "An atom is the smallest unit of matter. It consists of a nucleus (containing protons and neutrons) surrounded by electrons. The number of protons determines which element it is.",
            currentLanguage
        );
    } else if (lowerQuestion.includes('cell')) {
        return getTranslatedResponse(
            "A cell is the basic unit of life. There are two main types: prokaryotic cells (no nucleus, like bacteria) and eukaryotic cells (with nucleus, like animal and plant cells). Cells contain organelles that perform specific functions.",
            currentLanguage
        );
    } else if (lowerQuestion.includes('photosynthesis')) {
        return getTranslatedResponse(
            "Photosynthesis is the process by which plants use sunlight, water, and carbon dioxide to produce oxygen and glucose (food). The equation is: 6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂",
            currentLanguage
        );
    } else {
        return getTranslatedResponse(
            `Great question about ${currentSubject}! I can explain ${question} in detail. This topic involves understanding the fundamental concepts and their applications. Would you like me to break it down step by step?`,
            currentLanguage
        );
    }
}

function getTranslatedResponse(englishText, lang) {
    // In a real app, you'd use a translation API here
    // For now, we'll just return the English text with a language prefix
    const prefixes = {
        en: "",
        ig: "[Igbo] ",
        ha: "[Hausa] ",
        yo: "[Yoruba] ",
        ur: "[Urhobo] "
    };
    return prefixes[lang] + englishText;
}

// Math Solver
function insertMathSymbol(symbol) {
    const input = document.getElementById('mathInput');
    const start = input.selectionStart;
    const end = input.selectionEnd;
    const text = input.value;
    input.value = text.substring(0, start) + symbol + text.substring(end);
    input.selectionStart = input.selectionEnd = start + symbol.length;
    input.focus();
}

function solveMath() {
    const input = document.getElementById('mathInput');
    const problem = input.value.trim();
    
    if (!problem) {
        alert('Please enter a math problem!');
        return;
    }
    
    const solution = generateMathSolution(problem);
    displayMathSolution(solution);
}

function generateMathSolution(problem) {
    // This is a simplified example. In a real app, you'd use a proper math solving API
    return {
        problem: problem,
        steps: [
            {
                number: 1,
                description: "Identify the equation type",
                content: "This is a quadratic equation in the form ax² + bx + c = 0"
            },
            {
                number: 2,
                description: "Apply the quadratic formula",
                content: "x = (-b ± √(b² - 4ac)) / 2a"
            },
            {
                number: 3,
                description: "Substitute the values",
                content: "a = 2, b = 5, c = -3"
            },
            {
                number: 4,
                description: "Calculate the discriminant",
                content: "b² - 4ac = 25 - 4(2)(-3) = 25 + 24 = 49"
            },
            {
                number: 5,
                description: "Find the solutions",
                content: "x = (-5 ± √49) / 4 = (-5 ± 7) / 4"
            },
            {
                number: 6,
                description: "Final answer",
                content: "x₁ = 0.5, x₂ = -3"
            }
        ]
    };
}

function displayMathSolution(solution) {
    const outputDiv = document.getElementById('mathSolution');
    
    let html = `
        <h3>Solution for: ${solution.problem}</h3>
        <div class="solution-steps">
    `;
    
    solution.steps.forEach(step => {
        html += `
            <div class="solution-step">
                <div class="step-number">Step ${step.number}: ${step.description}</div>
                <div>${step.content}</div>
            </div>
        `;
    });
    
    html += '</div>';
    outputDiv.innerHTML = html;
}

function loadMathTopic(topic) {
    alert(`Loading ${topic} examples and practice problems...`);
}

// English Learning
function initializeEnglishSection() {
    const topicItems = document.querySelectorAll('.topic-item');
    topicItems.forEach(item => {
        item.addEventListener('click', function() {
            topicItems.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            const topicKey = this.dataset.topic;
            loadEnglishTopic(topicKey);
        });
    });
    
    // Load first topic
    loadEnglishTopic('concord');
}

function loadEnglishTopic(topicKey) {
    const topic = englishTopics[topicKey];
    if (!topic) return;
    
    const contentDiv = document.getElementById('englishTopicContent');
    const practiceDiv = document.getElementById('englishPractice');
    
    contentDiv.innerHTML = `
        <h2>${topic.title}</h2>
        ${topic.content}
    `;
    
    let practiceHtml = '';
    topic.practice.forEach((q, index) => {
        practiceHtml += `
            <div class="practice-question" data-question="${index}">
                <p><strong>Question ${index + 1}:</strong> ${q.question}</p>
                <div class="practice-options">
                    ${q.options.map((opt, i) => `
                        <div class="practice-option" onclick="checkEnglishAnswer(${index}, ${i}, '${topicKey}')">
                            ${opt}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    });
    
    practiceDiv.innerHTML = practiceHtml;
}

function checkEnglishAnswer(questionIndex, selectedOption, topicKey) {
    const topic = englishTopics[topicKey];
    const question = topic.practice[questionIndex];
    const options = document.querySelectorAll(`[data-question="${questionIndex}"] .practice-option`);
    
    options.forEach((opt, i) => {
        opt.classList.remove('correct', 'wrong');
        if (i === question.correct) {
            opt.classList.add('correct');
        } else if (i === selectedOption && i !== question.correct) {
            opt.classList.add('wrong');
        }
    });
}

// Quiz Section
function startQuiz(subject) {
    const quizContainer = document.getElementById('quizContainer');
    quizData = {
        subject: subject,
        questions: quizQuestions[subject],
        currentQuestion: 0
    };
    currentQuizQuestion = 0;
    quizAnswers = [];
    quizStartTime = Date.now();
    
    quizContainer.innerHTML = `
        <div class="quiz-interface">
            <div class="quiz-header">
                <div class="quiz-progress">
                    Question <span id="currentQ">1</span> of <span id="totalQ">${quizData.questions.length}</span>
                </div>
                <div class="quiz-timer">
                    <i class="fas fa-clock"></i>
                    <span id="quizTimer">00:00</span>
                </div>
            </div>
            <div class="quiz-question" id="quizQuestion">
                <!-- Question will be loaded here -->
            </div>
            <div class="quiz-navigation">
                <button class="btn btn-secondary" onclick="previousQuestion()" id="prevBtn" disabled>
                    <i class="fas fa-arrow-left"></i> Previous
                </button>
                <button class="btn btn-primary" onclick="nextQuestion()" id="nextBtn">
                    Next <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>
    `;
    
    loadQuizQuestion();
    startQuizTimer();
}

function loadQuizQuestion() {
    const question = quizData.questions[currentQuizQuestion];
    const questionDiv = document.getElementById('quizQuestion');
    
    let html = `
        <h3 class="question-text">${question.question}</h3>
        <div class="quiz-options">
    `;
    
    question.options.forEach((option, index) => {
        const isSelected = quizAnswers[currentQuizQuestion] === index;
        html += `
            <div class="quiz-option ${isSelected ? 'selected' : ''}" onclick="selectQuizOption(${index})">
                <strong>${String.fromCharCode(65 + index)}.</strong> ${option}
            </div>
        `;
    });
    
    html += '</div>';
    questionDiv.innerHTML = html;
    
    // Update navigation
    document.getElementById('currentQ').textContent = currentQuizQuestion + 1;
    document.getElementById('prevBtn').disabled = currentQuizQuestion === 0;
    document.getElementById('nextBtn').textContent = 
        currentQuizQuestion === quizData.questions.length - 1 ? 'Submit' : 'Next';
}

function selectQuizOption(optionIndex) {
    quizAnswers[currentQuizQuestion] = optionIndex;
    const options = document.querySelectorAll('.quiz-option');
    options.forEach((opt, i) => {
        opt.classList.toggle('selected', i === optionIndex);
    });
}

function previousQuestion() {
    if (currentQuizQuestion > 0) {
        currentQuizQuestion--;
        loadQuizQuestion();
    }
}

function nextQuestion() {
    if (currentQuizQuestion < quizData.questions.length - 1) {
        currentQuizQuestion++;
        loadQuizQuestion();
    } else {
        submitQuiz();
    }
}

function submitQuiz() {
    const endTime = Date.now();
    const timeTaken = Math.floor((endTime - quizStartTime) / 1000);
    
    let correctCount = 0;
    quizData.questions.forEach((q, i) => {
        if (quizAnswers[i] === q.correct) {
            correctCount++;
        }
    });
    
    const totalQuestions = quizData.questions.length;
    const percentage = Math.round((correctCount / totalQuestions) * 100);
    
    showQuizResults(correctCount, totalQuestions - correctCount, timeTaken, percentage);
}

function showQuizResults(correct, wrong, time, percentage) {
    document.getElementById('quizContainer').style.display = 'none';
    const resultsDiv = document.getElementById('quizResults');
    resultsDiv.style.display = 'block';
    
    document.getElementById('correctAnswers').textContent = correct;
    document.getElementById('wrongAnswers').textContent = wrong;
    document.getElementById('timeTaken').textContent = formatTime(time);
    document.getElementById('scorePercentage').textContent = percentage + '%';
    
    // Animate score circle
    const circle = document.getElementById('scoreCircle');
    const offset = 283 - (283 * percentage) / 100;
    setTimeout(() => {
        circle.style.strokeDashoffset = offset;
    }, 100);
    
    // Scroll to results
    resultsDiv.scrollIntoView({ behavior: 'smooth' });
}

function retakeQuiz() {
    document.getElementById('quizResults').style.display = 'none';
    document.getElementById('quizContainer').style.display = 'block';
    document.getElementById('quizContainer').innerHTML = `
        <div class="quiz-selection">
            <h3>Select Quiz Subject</h3>
            <div class="quiz-subjects">
                <div class="quiz-subject-card" onclick="startQuiz('physics')">
                    <i class="fas fa-atom"></i>
                    <h4>Physics Quiz</h4>
                    <p>10 Questions</p>
                </div>
                <div class="quiz-subject-card" onclick="startQuiz('chemistry')">
                    <i class="fas fa-flask"></i>
                    <h4>Chemistry Quiz</h4>
                    <p>10 Questions</p>
                </div>
                <div class="quiz-subject-card" onclick="startQuiz('biology')">
                    <i class="fas fa-dna"></i>
                    <h4>Biology Quiz</h4>
                    <p>10 Questions</p>
                </div>
                <div class="quiz-subject-card" onclick="startQuiz('mathematics')">
                    <i class="fas fa-calculator"></i>
                    <h4>Mathematics Quiz</h4>
                    <p>10 Questions</p>
                </div>
                <div class="quiz-subject-card" onclick="startQuiz('english')">
                    <i class="fas fa-book"></i>
                    <h4>English Quiz</h4>
                    <p>10 Questions</p>
                </div>
            </div>
        </div>
    `;
    scrollToSection('quiz');
}

function startQuizTimer() {
    let seconds = 0;
    const timerInterval = setInterval(() => {
        seconds++;
        const timerElement = document.getElementById('quizTimer');
        if (timerElement) {
            timerElement.textContent = formatTime(seconds);
        } else {
            clearInterval(timerInterval);
        }
    }, 1000);
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Scroll animations
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.1)';
    } else {
        navbar.style.boxShadow = 'var(--shadow)';
    }
});